package com.example.myapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText inputBox;
    Button submitBtn;
    TextView resultBox;
    long startTime;
    long lastKeyTime;
    int backspaceCount = 0;
    ArrayList<Long> interKeyIntervals = new ArrayList<>();
    String targetSentence = "Typing fast can be fun but tricky sometimes.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputBox = findViewById(R.id.userInput);
        submitBtn = findViewById(R.id.submitButton);
        resultBox = findViewById(R.id.outputText);

        // Start timing when user focuses on input
        inputBox.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                startTime = System.currentTimeMillis();
                lastKeyTime = startTime;
                backspaceCount = 0;
                interKeyIntervals.clear();
            }
        });

        inputBox.addTextChangedListener(new TextWatcher() {
            private String previousText = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                previousText = s.toString();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                long now = System.currentTimeMillis();
                interKeyIntervals.add(now - lastKeyTime);
                lastKeyTime = now;

                if (s.length() < previousText.length()) {
                    backspaceCount++;
                }
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });

        submitBtn.setOnClickListener(v -> {
            String typedText = inputBox.getText().toString();
            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;

            int charsTyped = typedText.length();
            double typingSpeed = charsTyped / (duration / 1000.0);
            int errors = calculateErrors(targetSentence, typedText);
            double meanInterval = interKeyIntervals.stream().mapToLong(Long::longValue).average().orElse(0.0);

            resultBox.setText(
                    "Typing speed: " + String.format("%.2f", typingSpeed) + " chars/sec\n" +
                            "Errors: " + errors + "\n" +
                            "Backspaces: " + backspaceCount + "\n" +
                            "Mean inter-key interval: " + String.format("%.2f", meanInterval) + " ms"
            );

            saveToCSV(targetSentence, typedText, typingSpeed, errors, backspaceCount, meanInterval);
        });
    }

    private int calculateErrors(String target, String typed) {
        int count = 0;
        int len = Math.min(target.length(), typed.length());
        for (int i = 0; i < len; i++) {
            if (target.charAt(i) != typed.charAt(i)) count++;
        }
        count += Math.abs(target.length() - typed.length());
        return count;
    }

    private void saveToCSV(String target, String typed, double speed, int errors,
                           int backspaces, double meanInterKeyInterval) {
        try {
            // Save CSV in app-specific external folder (accessible via USB)
            File folder = getExternalFilesDir(null);
            if (!folder.exists()) folder.mkdirs();

            File file = new File(folder, "typing_data.csv");
            boolean isNewFile = !file.exists();

            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);

            if (isNewFile) {
                bw.write("timestamp,target_text,typed_text,typing_speed,errors,backspaces,mean_inter_key_interval\n");
                android.util.Log.d("CSV", "New CSV file created at: " + file.getAbsolutePath());
            } else {
                android.util.Log.d("CSV", "Appending to existing CSV at: " + file.getAbsolutePath());
            }

            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

            String line = timestamp + ",\"" + target + "\",\"" + typed + "\"," +
                    speed + "," + errors + "," + backspaces + "," + meanInterKeyInterval + "\n";

            bw.write(line);
            bw.close();
            fw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


//package com.example.myapplication;
//
//import android.os.Bundle;
//import android.text.Editable;
//import android.text.TextWatcher;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//
//import java.io.File;
//import java.io.FileWriter;
//import java.io.BufferedWriter;
//
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import java.io.FileOutputStream;
//import java.io.OutputStreamWriter;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.Locale;
//
//import android.os.Environment;
//
//
//public class MainActivity extends AppCompatActivity {
//
//    EditText inputBox;
//    Button submitBtn;
//    TextView resultBox;
//    long startTime;
//    long lastKeyTime;
//    int backspaceCount = 0;
//    ArrayList<Long> interKeyIntervals = new ArrayList<>();
//    String targetSentence = "Typing fast can be fun but tricky sometimes.";
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        inputBox = findViewById(R.id.userInput);
//        submitBtn = findViewById(R.id.submitButton);
//        resultBox = findViewById(R.id.outputText);
//
//        // Start timing when user focuses on input
//        inputBox.setOnFocusChangeListener((v, hasFocus) -> {
//            if (hasFocus) {
//                startTime = System.currentTimeMillis();
//                lastKeyTime = startTime;
//                backspaceCount = 0;
//                interKeyIntervals.clear();
//            }
//        });
//
//        inputBox.addTextChangedListener(new TextWatcher() {
//            private String previousText = "";
//
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//                previousText = s.toString();
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                long now = System.currentTimeMillis();
//                interKeyIntervals.add(now - lastKeyTime);
//                lastKeyTime = now;
//
//                if (s.length() < previousText.length()) {
//                    backspaceCount++; // User pressed backspace
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) { }
//        });
//
//        submitBtn.setOnClickListener(v -> {
//            String typedText = inputBox.getText().toString();
//            long endTime = System.currentTimeMillis();
//            long duration = endTime - startTime; // in ms
//
//            int charsTyped = typedText.length();
//            double typingSpeed = charsTyped / (duration / 1000.0); // chars/sec
//            int errors = calculateErrors(targetSentence, typedText);
//            double meanInterval = interKeyIntervals.stream().mapToLong(Long::longValue).average().orElse(0.0);
//
//            resultBox.setText(
//                    "Typing speed: " + String.format("%.2f", typingSpeed) + " chars/sec\n" +
//                            "Errors: " + errors + "\n" +
//                            "Backspaces: " + backspaceCount + "\n" +
//                            "Mean inter-key interval: " + String.format("%.2f", meanInterval) + " ms"
//            );
//
//            saveToCSV(targetSentence, typedText, typingSpeed, errors, backspaceCount, meanInterval);
//        });
//    }
//
//    private int calculateErrors(String target, String typed) {
//        int count = 0;
//        int len = Math.min(target.length(), typed.length());
//        for (int i = 0; i < len; i++) {
//            if (target.charAt(i) != typed.charAt(i)) count++;
//        }
//        count += Math.abs(target.length() - typed.length());
//        return count;
//    }
//
////    private void saveToCSV(String target, String typed, double speed, int errors,
////                           int backspaces, double meanInterKeyInterval) {
////        try {
////            // Change this path to any folder on your PC where you want the CSV
////            String path = getExternalFilesDir(null) + "/typing_data.csv";
////            File file = new File(path);
////            boolean isNewFile = !file.exists();
////
////            FileWriter fw = new FileWriter(file, true); // append mode
////            BufferedWriter bw = new BufferedWriter(fw);
////
////            // Write header only if file is new
////            if (isNewFile) {
////                bw.write("timestamp,target_text,typed_text,typing_speed,errors,backspaces,mean_inter_key_interval\n");
////            }
////
////            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
////                    .format(new Date());
////
////            String line = timestamp + ",\"" + target + "\",\"" + typed + "\"," +
////                    speed + "," + errors + "," + backspaces + "," + meanInterKeyInterval + "\n";
////
////            bw.write(line);
////            bw.close();
////            fw.close();
////
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////    }
//
//    private void saveToCSV(String target, String typed, double speed, int errors,
//                           int backspaces, double meanInterKeyInterval) {
//        try {
//            File folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
//            if (!folder.exists()) folder.mkdirs();
//
//            File file = new File(folder, "typing_data.csv");
//            boolean isNewFile = !file.exists();
//
//            FileWriter fw = new FileWriter(file, true);
//            BufferedWriter bw = new BufferedWriter(fw);
//
//            if (isNewFile) {
//                bw.write("timestamp,target_text,typed_text,typing_speed,errors,backspaces,mean_inter_key_interval\n");
//                System.out.println("New CSV file created at: " + file.getAbsolutePath());
//            } else {
//                System.out.println("Appending data to existing CSV at: " + file.getAbsolutePath());
//            }
//
//            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
//
//            String line = timestamp + ",\"" + target + "\",\"" + typed + "\"," +
//                    speed + "," + errors + "," + backspaces + "," + meanInterKeyInterval + "\n";
//
//            bw.write(line);
//            bw.close();
//            fw.close();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//
//
//}
